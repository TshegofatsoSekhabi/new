-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2014 at 09:36 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cellphone`
--
CREATE DATABASE IF NOT EXISTS `cellphone` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cellphone`;

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE IF NOT EXISTS `tblcategory` (
  `category_Name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`category_Name`) VALUES
('Nokia'),
('Samsung'),
('Nokia'),
('Samsung');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE IF NOT EXISTS `tbllogin` (
  `Email` varchar(25) NOT NULL,
  `Password` varchar(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`Email`, `Password`) VALUES
('', ''),
('thbusang@gmail.com', '4555651');

-- --------------------------------------------------------

--
-- Table structure for table `tblonlineorder`
--

CREATE TABLE IF NOT EXISTS `tblonlineorder` (
  `orderName` varchar(50) NOT NULL,
  `orderDate` varchar(50) NOT NULL,
  `orderTotAmt` decimal(11,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE IF NOT EXISTS `tblproduct` (
  `price` double(5,2) NOT NULL,
  `categoryDescription` varchar(50) NOT NULL,
  `productName` varchar(50) NOT NULL,
  `productCode` varchar(10) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`price`, `categoryDescription`, `productName`, `productCode`, `qty`) VALUES
(999.99, 'Samsung', 'Galaxy S4 mini', 'I900G', 0),
(999.99, 'Nokia', 'nokia n8', 'n8-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblregister`
--

CREATE TABLE IF NOT EXISTS `tblregister` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `Email` varbinary(50) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Address` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tblregister`
--

INSERT INTO `tblregister` (`ID`, `Fname`, `Lname`, `Email`, `Password`, `Address`) VALUES
(1, 'thabo', 'busang', 'thbusang@gmail.com', '4555651', 'cvbhjsdjxcvdsjhsv'),
(2, 'NKO', 'SEKHABI', 'nko@webmail.com', '45588', 'dfbdfhrfdf'),
(7, 'thabang', 'masango', 'hhhhhh', 'rgbjfbgbsdjogbojb zo', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
